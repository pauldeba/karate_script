package com.standard.qa.db;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class OracleSqlUtil extends SpringSqlUtil {

    protected static Log log = LogFactory.getLog(OracleSqlUtil.class);

    private static final String driverClassName = "oracle.jdbc.driver.OracleDriver";

    private final Map<String, Object> oracleConfig;

    private final String ORACLE_PASSWORD;

    public OracleSqlUtil(final Map<String, Object> oConfig, final String password) {
        oracleConfig = oConfig;
        ORACLE_PASSWORD = password;
        configureDriver();
    }

    private void configureDriver() {
        final String hostname = (String) oracleConfig.get("hostname");
        final String port = (String) oracleConfig.get("port");
        final String username = (String) oracleConfig.get("username");
        final String sid = (String) oracleConfig.get("sid");
        final String sidUrl = "jdbc:oracle:thin:@%s:%s:%s";
        final String formattedUrl = String.format(sidUrl, hostname, port, sid);

        final DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(formattedUrl); // includes host, port, and sid
        dataSource.setUsername(username);
        dataSource.setPassword(getPasswordForThisResource());

        jdbc = new JdbcTemplate(dataSource);

        log.info(String.format("init Oracle jdbc template: %s", formattedUrl));
    }

    /**
     * Example query to show that querying Oracle is possible.
     *
     * @return a json object of table names
     */
    public List<String> tables() {
        String prefix = "3";
        String query = "SELECT TRANSACTION_ID FROM audit_event WHERE ROWNUM<%s";
        String formattedQuery = String.format(query, prefix);
        List<Map<String, Object>> items = readRows(formattedQuery);
        List<String> results = items.stream()
                .map(m -> (String) m.get("TRANSACTION_ID"))
                .collect(Collectors.toList());
        return results;
    }

    public List<Map<String, Object>> queryDB(String query) {
        List<Map<String, Object>> items = readRows(query);
        return items;
    }

    /**
     * Use this method to debug this Java code
     */
    public static void main(String[] args) {
        Map<String, Object> oraConfig = new HashMap();
        oraConfig.put("hostname", "seq1");
        oraConfig.put("port", "1521");
        oraConfig.put("username", "OPS$USERID");
        oraConfig.put("sid", "itxi");
        OracleSqlUtil oracleSqlUtil = new OracleSqlUtil(oraConfig, "");
        List<String> tables = oracleSqlUtil.tables();
        tables.stream().forEach(t -> {
            System.out.print(t);
        });
    }

    public List<Map<String, Object>> resultSetToArrayList(ResultSet rs) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int columns = md.getColumnCount();
        List<Map<String, Object>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String, Object> row = new HashMap<>(columns);
            for (int i = 1; i <= columns; ++i) {
                row.put(md.getColumnName(i), rs.getObject(i));
            }
            list.add(row);
        }
        return list;
    }

    @Override
    public String getPasswordForThisResource() {
        return ORACLE_PASSWORD;
    }

}
