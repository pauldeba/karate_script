package com.standard.qa.jms;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;
import com.intuit.karate.Json;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;
import javax.net.ssl.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertPathBuilder;
import java.security.cert.PKIXBuilderParameters;
import java.security.cert.PKIXRevocationChecker;
import java.security.cert.X509CertSelector;
import java.time.Duration;
import java.time.Instant;
import java.util.EnumSet;
import java.util.Map;

public class SSLAuditProducer {

    private static final Logger logger = LoggerFactory.getLogger(SSLAuditProducer.class);

    private Connection connection;
    private MQQueueConnectionFactory mqQueueConnectionFactory;
    private Session session;
    private Destination destination;
    public final Map<String, Object> MQ_CONFIG;

    private static final String SUCCESS_STATUS = "JMS_SUCCESS";
    private static final String KEYSTORE_PASS = "mq$client";
    private static final String SERVICE_NAME = "eb-get-cov-benefits-service";
    private static final String JKS_FILE = "src/test/resources/mq_client.jks";

    private MessageProducer sender;

    public SSLAuditProducer(Map<String, Object> config) {
        setDebugProps();
        MQ_CONFIG = config;
        System.setProperty(SUCCESS_STATUS, "false");
        if (!Files.exists(Paths.get(JKS_FILE))) {
            throw new RuntimeException("JMS connection requires Java keystore file.");
        }
        try {
            connection = getMQConnectionFactory().createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            destination = session.createQueue(String.valueOf(MQ_CONFIG.get("name")));
            sender = session.createProducer(destination);
            connection.start();
        } catch (Exception e) {
            System.setProperty(SUCCESS_STATUS, "false");
            throw new RuntimeException(
                    "Error initializing the SSL connection to MQ.  You may be missing required parameters or properties to get the connection.",
                    e);
        }
    }

    public MQQueueConnectionFactory getMQConnectionFactory() {
        mqQueueConnectionFactory = new MQQueueConnectionFactory();
        try {
            mqQueueConnectionFactory.setHostName(String.valueOf(MQ_CONFIG.get("host")));
            mqQueueConnectionFactory.setQueueManager(String.valueOf(MQ_CONFIG.get("manager")));
            mqQueueConnectionFactory.setPort((Integer) MQ_CONFIG.get("port"));
            mqQueueConnectionFactory.setChannel(String.valueOf(MQ_CONFIG.get("channel")));
            mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
            mqQueueConnectionFactory.setCCSID((Integer) MQ_CONFIG.get("ccsid"));
            mqQueueConnectionFactory.setAppName(SERVICE_NAME);
            mqQueueConnectionFactory.setStringProperty(WMQConstants.WMQ_SSL_CIPHER_SPEC,
                    "TLS_RSA_WITH_AES_128_GCM_SHA256");
            mqQueueConnectionFactory.setBooleanProperty(WMQConstants.USER_AUTHENTICATION_MQCSP, true);
            System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", "false");
            mqQueueConnectionFactory.setStringProperty(WMQConstants.USERID, String.valueOf(MQ_CONFIG.get("user")));
            mqQueueConnectionFactory.setStringProperty(WMQConstants.PASSWORD, String.valueOf(MQ_CONFIG.get("secret")));
            SSLSocketFactory sslSocketFactory = sslContext().getSocketFactory();
            mqQueueConnectionFactory.setSSLSocketFactory(sslSocketFactory);
        } catch (JMSException e) {
            System.setProperty(SUCCESS_STATUS, "false");
            logger.error("Error in connection factory.", e);
        }
        return mqQueueConnectionFactory;
    }

    public SSLContext sslContext() {
        File file = new File(JKS_FILE);
        String jkspath = file.getAbsolutePath();
        System.out.println(jkspath);
        try (InputStream cert = new FileInputStream(jkspath)) {

            final KeyStore caCertsKeyStore = KeyStore.getInstance("JKS");
            caCertsKeyStore.load(cert, KEYSTORE_PASS.toCharArray());

            final KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            final TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());

            CertPathBuilder cpb = CertPathBuilder.getInstance("PKIX");
            PKIXRevocationChecker rc = (PKIXRevocationChecker) cpb.getRevocationChecker();
            rc.setOptions(
                    EnumSet.of(PKIXRevocationChecker.Option.PREFER_CRLS, PKIXRevocationChecker.Option.ONLY_END_ENTITY,
                            PKIXRevocationChecker.Option.SOFT_FAIL, PKIXRevocationChecker.Option.NO_FALLBACK));

            PKIXBuilderParameters pkixParams = new PKIXBuilderParameters(caCertsKeyStore, new X509CertSelector());
            pkixParams.addCertPathChecker(rc);

            kmf.init(caCertsKeyStore, KEYSTORE_PASS.toCharArray());
            tmf.init(new CertPathTrustManagerParameters(pkixParams));

            final SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), new SecureRandom());

            return sslContext;

        } catch (Exception e) {
            System.setProperty(SUCCESS_STATUS, "false");
            throw new RuntimeException("Exception creating SSLContext", e);
        }
    }

    public boolean isValidXml(String xmlString) {
        boolean result = false;
        try {
            InputStream stream = new ByteArrayInputStream(xmlString.getBytes("UTF-8"));
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            dBuilder.parse(stream);
            result = true;
        } catch (Exception e) {
            result = false;
        }
        return result;
    }

    /**
     * Use this only for Debugging in IntelliJ-IDEA. (not VSCode)
     * 
     * @param args
     */
    public static void main(final String[] args) {
        String configString = "{\"manager\": \"QL3002S1\", \"host\": \"mqint-eb.standard.com\", \"port\": 6531, \"channel\": \"MQ.EXPLORER\", \"ccsid\": 1208, \"name\": \"EB.DFB.MDHEVENT.REQUEST.Q\", \"user\": \"S007570\"}";
        com.intuit.karate.Json config = new com.intuit.karate.Json(configString);
        config.set("secret", "20Twenty#"); // normally, get this from TDM database
        SSLAuditProducer emailProducer = new SSLAuditProducer(config.asMap());
        emailProducer.pushMessage(
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <MemberDataHubOutputEvent> <version>1.0</version> <Control> <TransactionId>20161202173913000901</TransactionId> <TransactionType>Publish</TransactionType> <SourceSystem> <Name>ONE TOUCH TOOL</Name> <Actor>testcon</Actor> <Action>Publish</Action> <Entity>Member</Entity> <TimeStamp>2016-12-02 17:40:27</TimeStamp> <Host>etlsys1</Host> <IPAddress>192.168.169.209</IPAddress> </SourceSystem> <FileAttributes> <FileId>41859</FileId> <FileName>10109510_1_20160824.csv</FileName> <FileDate>2016-08-24 00:00:00</FileDate> <ExtractRunNumber>1</ExtractRunNumber> <SfgOrgId>O0000041F2</SfgOrgId> <GroupId>10109510</GroupId> <GroupName>Livingston Parish Clerk of Court</GroupName> </FileAttributes> <Services> <Service> <Seq>41859</Seq> <ServiceName>Billing</ServiceName> <RecordEffectiveDate/> <RecordThroughDate/> </Service> <Service> <Seq>41859</Seq> <ServiceName>EoiExtract</ServiceName> <RecordEffectiveDate/> <RecordThroughDate/> </Service> </Services> <ChangeDomains> <ChangeDomain> <ChangeDomainNm>ENROLLMENT_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>EMAIL_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>WORK_STATE_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>SCHD_WRK_HRS_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>ACT_WRK_HRS_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>DEMOGRAPHIC_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>BILLING_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>OFFERING_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>PERSON_NM_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>EMP_MBR_TENURE_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>ACT_EARN_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>SCHD_EARN_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>PHONE_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>DEPENDENT_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>EMP_MBR_DETAIL_FLG</ChangeDomainNm> <ChangeDomainValue>Y</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>IDENTIFIER_FLG</ChangeDomainNm> <ChangeDomainValue>Y</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>BEN_DES_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>HR_CONTACT_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>WITHHOLDING_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>CLASS_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>MEMBERSHIP_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>PAYROLL_DTL_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>PAYROLL_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>ADDRESS_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> <ChangeDomain> <ChangeDomainNm>RPT_CAT_UDF_FLG</ChangeDomainNm> <ChangeDomainValue>N</ChangeDomainValue> </ChangeDomain> </ChangeDomains> </Control> <Body> <Person> <SfgId>B00321CBD</SfgId> <Ids> <Id> <identifierType>Billing Service Id</identifierType> <OrgPersonIdentifierSeq>4604299</OrgPersonIdentifierSeq> <Value>366667317</Value> <RecordEffectiveDate>2016-08-24</RecordEffectiveDate> <RecordThroughDate/> </Id> <Id> <identifierType>Social Security Number</identifierType> <OrgPersonIdentifierSeq>4604298</OrgPersonIdentifierSeq> <Value>366667317</Value> <RecordEffectiveDate>2016-08-24</RecordEffectiveDate> <RecordThroughDate/> </Id> </Ids> <Names> <Name> <nameUsageType>Legal</nameUsageType> <OrgPersonNameSeq>2707409</OrgPersonNameSeq> <PrefixName/> <FirstName>Young</FirstName> <MiddleName/> <LastName>Christen</LastName> <SuffixName/> <PreferFirstName/> <GenSuffixName/> </Name> </Names> <Demographic> <OrgPersonDemographicSeq>3019108</OrgPersonDemographicSeq> <BirthDate>1984-09-30</BirthDate> <DeceasedDate/> <MaritalStatusCode/> <LanguagePreferCode/> <StudentFlag/> <SmokerFlag/> <GenderCode>F</GenderCode> </Demographic> <Employments> <Employment> <tenureType>EMP</tenureType> <EmploymentMembershipTenureSeq>2554268</EmploymentMembershipTenureSeq> <EmploymentMembershipDetailSeq>6656136</EmploymentMembershipDetailSeq> <JobCategory/> <JobTitleText>Deputy Clerk</JobTitleText> <EmploymentStatusType/> <OriginalHireDate/> <AdjustedOriginalHireDate/> <EmployerAffiliateName/> <PreviousHireDate/> <RegTempCode/> <FullPartTimeCode/> <PartTimeDetailText/> <ExemptCode/> <EmpLocationCode/> <WorkLocationName>Portland</WorkLocationName> <UnionFlag/> <UnionName/> <DeptId/> <DeptNm/> <ManagerEEId/> <SpouseEEId/> <EarningTypCd/> <KeyEmpFlg/> <LastWorkedDt/> <FiftyEmp75MileTxt/> <ConfidentialEmplFlg/> <OccupationCd/> <EmpUDF01Txt/> <EmpUDF02Txt/> <EmpUDF03Txt/> <EmpUDF04Txt/> <EmpUDF05Txt/> <EmpUDF06Txt/> <EmpUDF07Txt/> <EmpUDF08Txt/> <EmpUDF09Txt/> <EmpUDF10Txt/> <CurrentHireDate>2014-11-03</CurrentHireDate> <TermDate/> </Employment> </Employments> <Enrollments> <Enrollment> <EnrollmentSeq>12065218</EnrollmentSeq> <EmployeeRetireeIndicator>E</EmployeeRetireeIndicator> <ChangeDate>2016-11-29</ChangeDate> <CoverageEffectiveDate>2014-11-03</CoverageEffectiveDate> <CvrgThruDt/> <CoverageElectedDate/> <EstCvrgThruDt/> <EnrollmentStatusInd>Covered</EnrollmentStatusInd> <PendingElectionMthdTxt/> <ApplicationDt/> <CvrgTermReasonTxt/> <SelectedUnitOrAmount>250000</SelectedUnitOrAmount> <SelectedUnitOrAmtInd>Selected Amount</SelectedUnitOrAmtInd> <AgeBracketTopTxt/> <SmokerInd/> <SpouseBirthDt/> <SpouseAgeNbr/> <SpouseAgeBracketTopTxt/> <RecEffDt>2016-08-22</RecEffDt> <RecThruDt/> <TermRecEffDt/> <CaVdiEligFlg/> <NjTdbEligFlg/> <StateDiEligFlg/> <PendingAmtTyp/> <SourceId/> <Source/> <FamilyInd/> <ContractNbr>754198</ContractNbr> <PlanId>A</PlanId> <ProductId>AA</ProductId> <EmployerPlanCode/> <FamilyCvgTypInd/> <BenefitPercentCode/> <FlatBenefitAmount/> <BenefitWaitingPeriodNumber/> <MaximumBenefitPeriodNumber/> <EarningMultiplier/> <IncrementalBenefitAmount/> <BNPlanCode/> <BenefitTitle/> <ScheduleId/> </Enrollment> <Enrollment> <EnrollmentSeq>12065226</EnrollmentSeq> <EmployeeRetireeIndicator>E</EmployeeRetireeIndicator> <ChangeDate>2016-11-29</ChangeDate> <CoverageEffectiveDate>2014-11-03</CoverageEffectiveDate> <CvrgThruDt/> <CoverageElectedDate/> <EstCvrgThruDt/> <EnrollmentStatusInd>Covered</EnrollmentStatusInd> <PendingElectionMthdTxt/> <ApplicationDt/> <CvrgTermReasonTxt/> <SelectedUnitOrAmount>250000</SelectedUnitOrAmount> <SelectedUnitOrAmtInd>Selected Amount</SelectedUnitOrAmtInd> <AgeBracketTopTxt/> <SmokerInd/> <SpouseBirthDt/> <SpouseAgeNbr/> <SpouseAgeBracketTopTxt/> <RecEffDt>2016-08-22</RecEffDt> <RecThruDt/> <TermRecEffDt/> <CaVdiEligFlg/> <NjTdbEligFlg/> <StateDiEligFlg/> <PendingAmtTyp/> <SourceId/> <Source/> <FamilyInd/> <ContractNbr>754198</ContractNbr> <PlanId>A</PlanId> <ProductId>AL</ProductId> <EmployerPlanCode/> <FamilyCvgTypInd/> <BenefitPercentCode/> <FlatBenefitAmount/> <BenefitWaitingPeriodNumber/> <MaximumBenefitPeriodNumber/> <EarningMultiplier/> <IncrementalBenefitAmount/> <BNPlanCode/> <BenefitTitle/> <ScheduleId/> </Enrollment> </Enrollments> <Earnings> <Earning> <earningType>PDE</earningType> <EarningSeq>9691743</EarningSeq> <FrequencyType>Annual</FrequencyType> <PayFrequencyType/> <EarningModeCode>A</EarningModeCode> <EarningUnitText>35360</EarningUnitText> <EarningDate>2014-11-03</EarningDate> <EstimatedEarningDate>2014-11-03</EstimatedEarningDate> <PeriodStartDate>2016-08-22</PeriodStartDate> <PeriodThruDate/> <CreatedDate>2016-11-29</CreatedDate> </Earning> </Earnings> <WorkStates> <WorkState> <WorkStateSeq>2502604</WorkStateSeq> <WorkStateCode>MN</WorkStateCode> <WorkStateEffectiveDate/> <WorkStateEstimatedEffectiveDate>2016-08-22</WorkStateEstimatedEffectiveDate> <WorkStateEstimatedThroughDate/> <RecordEffectiveDate>2016-08-22</RecordEffectiveDate> <RecordThroughDate/> </WorkState> </WorkStates> <RelatedPersons> <RelatedPerson> <relationshipType>Partner</relationshipType> <DependentSeq>66135</DependentSeq> <FirstName>Isaac</FirstName> <MiddleName/> <LastName>Young</LastName> <GenSuffixName/> <GenderCode>M</GenderCode> <BirthDate>1970-12-28</BirthDate> <SmokerIndicator/> </RelatedPerson> </RelatedPersons> <Billings> <Billing> <BillingSeq>68824</BillingSeq> <IssuingCompanyId>SI</IssuingCompanyId> <Policy>754198</Policy> <Division/> <DivisionEffectiveDate/> <BillingCategory/> <BillingCategoryEffectiveDate/> <BillingProduct/> <FamilyIndicator>C</FamilyIndicator> <FamilyIndicatorEffectiveDate/> <PolicyEligibilityDate>2014-11-03</PolicyEligibilityDate> <PolicyTerminationDate/> <QualEventDate/> <GrandfatheredFlag/> <MultiDivisionFlag>N</MultiDivisionFlag> <EmployerDivisionCode/> <EmployerBillingCategoryCode/> <ChangeEffectiveDate/> </Billing> </Billings> </Person> </Body> </MemberDataHubOutputEvent>");
    }

    public String pushMessage(String message) {
        try {
            if (message.contains("File#")) {
                return pushFile(new File(message.replace("File#", "")));
            }
            Message messageTxt;
            if (isValidXml((String) message)) {
                messageTxt = session.createTextMessage((String) message);
            } else {
                messageTxt = session.createTextMessage(new Json((String) message).toString());
            }
            sender.send(messageTxt);
            sender.close();
            System.setProperty(SUCCESS_STATUS, "true");
        } catch (Exception e) {
            logger.error("Error encountered while pushing message into queue.", e);
            System.setProperty(SUCCESS_STATUS, "false");
        } finally {
            stop();
        }
        return System.getProperty(SUCCESS_STATUS);
    }

    /**
     * Calling this currently will invalidate this database access object, unless
     * this code is changed.
     */
    void stop() {
        try {
            if (sender != null) {
                sender.close();
            }
            if (connection != null) {
                connection.close();
            }
            if (mqQueueConnectionFactory != null) {
                mqQueueConnectionFactory = null;
            }
        } catch (JMSException e) {
            System.setProperty(SUCCESS_STATUS, "false");
            logger.error("Error in stopping client connection to queue.", e);
        }
    }

    private static void setDebugProps() {
        try {
            if (Files.exists(Paths.get("trace.trc"))) {
                Files.delete(Paths.get("trace.trc"));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // System.setProperty("com.ibm.msg.client.commonservices.trace.status", "ON");
        // System.setProperty("com.ibm.msg.client.commonservices.trace.outputName",
        // "trace.trc");
        // System.setProperty("com.ibm.msg.client.commonservices.trace.level", "1");
    }

    private void sendFileAsBytesMessage(File file) throws JMSException, IOException {
        Instant start = Instant.now();
        BytesMessage bytesMessage = session.createBytesMessage();
        bytesMessage.setStringProperty("fileName", file.getName());
        bytesMessage.writeBytes(readfileAsBytes(file));
        sender.send(bytesMessage);
        Instant end = Instant.now();
        System.out.println("sendFileAsBytesMessage for [" + file.getName() + "], took " + Duration.between(start, end));
    }

    public byte[] readfileAsBytes(File file) throws IOException {
        try (RandomAccessFile accessFile = new RandomAccessFile(file, "r")) {
            byte[] bytes = new byte[(int) accessFile.length()];
            accessFile.readFully(bytes);
            return bytes;
        }
    }

    public void writeFile(byte[] bytes, String fileName) throws IOException {
        File file = new File(fileName);
        try (RandomAccessFile accessFile = new RandomAccessFile(file, "rw")) {
            accessFile.write(bytes);
        }
    }

    public String pushFile(File file) {
        try {
            sendFileAsBytesMessage(file);
            System.setProperty(SUCCESS_STATUS, "true");
        } catch (Exception e) {
            logger.error("Error encountered while pushing file into queue.", e);
            System.setProperty(SUCCESS_STATUS, "false");
        }
        return System.getProperty(SUCCESS_STATUS);
    }
}
