package com.standard.qa.db;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Use this JDBC method in favor of Spring-JDBC because you will be able to debug this this class.
 */
public class MsSqlDBUtil {

    protected static Log log = LogFactory.getLog(MsSqlDBUtil.class);
    private static final String TD_PASS = "DB.password";
    private static final String driverClassName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private final String formattedUrl;

    public MsSqlDBUtil(Map<String, Object> config) {
        String hostname = (String)config.get("hostname");
        String port = (String)config.get("port");
        String database = (String)config.get("database");
        String username = (String)config.get("username");
        String url = "jdbc:sqlserver://%s:%s;databaseName=%s;user=%s;password=%s";
        formattedUrl = String.format(url, hostname, port, database, username, getPasswordForThisResource());
    }

    public List<Map<String, Object>> queryDB(String query) {
        loadDriverOnClasspath();
        try (Connection conn = DriverManager.getConnection(formattedUrl);
             Statement stmt = conn.createStatement();
        ) {
            System.out.println(String.format("Connection made to MsSql jdbc: %s", formattedUrl));
            return resultSetToArrayList(stmt.executeQuery(query));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getPasswordForThisResource() {
        String tdPassword = System.getProperty(TD_PASS);
        Objects.requireNonNull(tdPassword, "The DB.password arg is required to be passed to this test suite.");
        System.setProperty("TD_PASS", tdPassword); //NOTE: could be necessary if you want to use our in-house TDM Java lib
        return tdPassword;
    }
   /**
    * Since this always returns a list of map values, you have to extract the list item before you access the map key
    *   For example, to get a single value:   var secret = getOracleCredential(global.oracle.username)[0].credential;
    * @param rs
    * @return
    * @throws SQLException
    */
    public List<Map<String, Object>> resultSetToArrayList(ResultSet rs) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int columns = md.getColumnCount();
        List<Map<String, Object>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String, Object> row = new HashMap<>(columns);
            for (int i = 1; i <= columns; ++i) {
                row.put(md.getColumnName(i), rs.getObject(i));
            }
            list.add(row);
        }
        return list;
    }

    /**
     * This is the 'JDBC driver shim' workaround for debugging Karate in VSCode.
     */
    private void loadDriverOnClasspath() {
        try {
            Driver driver = (Driver) Class.forName(driverClassName).newInstance();
            DriverManager.registerDriver(new DriverShim(driver));
        } catch (InstantiationException|IllegalAccessException|ClassNotFoundException|SQLException e) {
            log.error("Error loading JDBC driver.", e);
        }
    }

}

